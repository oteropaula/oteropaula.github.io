#include <WiFi.h>
#include <WebServer.h>
#include "FS.h"
#include "SPIFFS.h"

// Configuración de las credenciales WiFi
const char* ssid = "ESP32-AP04";
const char* password = "123456789";

// Creación de un servidor web en el puerto 80
WebServer server(80);

struct Melody {
    String name;
};

#define MAX_MELODIES 10
Melody createdMelodies[MAX_MELODIES];
int createdMelodyCount = 0;

bool melodyPlaying = false; // Variable de control para evitar múltiples reproducciones simultáneas

// Configuración inicial del sistema
void setup() {
    Serial.begin(115200);
    Serial2.begin(115200);    
    setupSPIFFS();
    setupWiFi();
    setupServer();
}

// Inicializa el sistema de archivos SPIFFS
void setupSPIFFS() {
  if (!SPIFFS.begin(true)) {
        Serial.println("SPIFFS Mount Failed");
        return;
  }
}

// Configura el punto de acceso WiFi
void setupWiFi() {
    Serial.println();
    Serial.println("Configuring access point...");
    WiFi.softAP(ssid, password);
    IPAddress myIP = WiFi.softAPIP();
    Serial.print("AP IP address: ");
    Serial.println(myIP);
}

// Configura las rutas y funciones del servidor web
void setupServer() {
    server.on("/", handleRoot); // Maneja la ruta raíz "/"
    server.on("/play", handlePlay); // Maneja la ruta "/play"
    server.on("/melodies", handleMelodies); // Maneja la ruta "/melodies"
    server.on("/icono.jpg", handleIcon); // Maneja la ruta "/icono.jpg"
    server.on("/image.png", handleImage); // Maneja la ruta "/image.jpg"
    server.begin();
    Serial.println("HTTP server started");
}

// Maneja la solicitud de la página HTML principal
void handleRoot() {
    File file = SPIFFS.open("/index.html"); // Abre el archivo index.html desde SPIFFS
    if (!file) {
        server.send(500, "text/plain", "Failed to open /index.html"); // Envía un error si el archivo no se puede abrir
        return;
    }

    String html;
    while (file.available()) {
        html += char(file.read()); // Lee el contenido del archivo
    }
    file.close();

    server.send(200, "text/html", html); // Envía el contenido HTML al cliente
}

// Maneja la solicitud del listado de melodías
void handleMelodies() {
    String melodiesList = "<b>Melodías predefinidas</b>";
    for (int i = 0; i < 4; i++) {
        melodiesList += "<li><a href=\"#\" onclick=\"playMelody('Melodia " + String((char)('A' + i)) + "')\">Melodia " + String((char)('A' + i)) + "</a></li>";
    }

    melodiesList += "<hr>";

    melodiesList += "<b>Melodías creadas</b>";
    for (int i = 0; i < createdMelodyCount; i++) {
        melodiesList += "<li><a href=\"#\" onclick=\"playMelody('" + createdMelodies[i].name + "')\">" + createdMelodies[i].name + "</a></li>";
    }

    server.send(200, "text/plain", melodiesList); // Envía el listado de melodías al cliente
}

// Maneja la solicitud de reproducción de las melodías
void handlePlay() {
    if (!server.hasArg("melody") || melodyPlaying) {
        server.send(400, "text/plain", "Invalid request");
        return;
    }

    String melody = server.arg("melody"); // Obtiene el nombre de la melodía
    melody.trim();

    Serial.println("M:" + melody);
    Serial2.println("M:" + melody);

    server.send(200, "text/plain", "Melody playing: " + melody);

    melodyPlaying = true; // Marca que una melodía está en reproducción
    delay(1000); // Espera de corta duración para evitar múltiples reproducciones simultáneas
    melodyPlaying = false; // Marca que la reproducción ha terminado
}

// Maneja la solicitud del icono de la página web
void handleIcon() {
    File file = SPIFFS.open("/icono.jpg"); // Abre el archivo del icono desde SPIFFS
    if (!file) {
        server.send(404, "text/plain", "Icon not found");
        return;
    }

    server.streamFile(file, "image/jpg"); // Envía el archivo de imagen al cliente
    file.close();
}

// Maneja la solicitud de la imagen de la página web
void handleImage() {
    File file = SPIFFS.open("/image.png"); // Abre el archivo de imagen desde SPIFFS
    if (!file) {
        server.send(404, "text/plain", "Image not found");
        return;
    }

    server.streamFile(file, "image/png"); // Envía el archivo de imagen al cliente
    file.close();
}

void loop() {
    server.handleClient(); // Maneja las solicitudes del cliente

    // Lee los mensajes de Serial2
    if (Serial2.available()) {
        String message = Serial2.readStringUntil('\n'); // Lee un mensaje hasta el carácter de nueva línea
        if (message.startsWith("M:")) {
            String melodyName = message.substring(2); // Extrae el nombre de la melodía del mensaje
            melodyName.trim(); // Elimina espacios y nuevas líneas sobrantes

            if (createdMelodyCount < MAX_MELODIES) {
                createdMelodies[createdMelodyCount].name = melodyName; // Almacena el nombre de la melodía en el array
                createdMelodyCount++;
                Serial.println("Melody received: " + melodyName);
            }
        }
    }
}