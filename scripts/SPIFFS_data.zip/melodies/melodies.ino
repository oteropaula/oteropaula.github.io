#include <rgb_lcd.h>
#include "pitches.h"

#define MELODY_NAME_LEN 15
#define MELODY_NOTES 30
#define MAX_MELODIES 10

int pinA = 2;
int pinB = 3;
int pinSw = 4;
int pinZ = 8;

int currentNoteIndex = 0;
int currentMelodyIndex = 0;
int noteSelection = 0;
int melodyCount = 0;
bool inCreationMode = true;
bool confirmSave = false;
unsigned long lastSwitchPressTime = 0;
int switchPressCount = 0;
unsigned long debounceTime = 200;

const int noteFrequencies[] = { NOTE_C4, NOTE_D4, NOTE_E4, NOTE_F4, NOTE_G4, NOTE_A4, NOTE_B4, NOTE_C5 };
const char* noteNames[] = { "DO", "RE", "MI", "FA", "SOL", "LA", "SI", "DO" };

rgb_lcd lcd;

typedef struct {
    int frequency;
    int duration;
} Note;

typedef struct {
    char name[MELODY_NAME_LEN + 1];
    Note notes[MELODY_NOTES];
    int noteCount;
} Melody;

Melody melodies[MAX_MELODIES];

// Melodías predefinidas
const Melody predefinedMelodies[] = {
    // Star Wars
    { "Melodia A", 
        {
            {NOTE_G4, 500}, {NOTE_G4, 500}, {NOTE_G4, 500}, {NOTE_E4, 375}, {NOTE_B4, 125}, {NOTE_G4, 500}, {NOTE_E4, 375}, {NOTE_B4, 125}, {NOTE_G4, 1000}, // Primer compás
            {NOTE_D5, 500}, {NOTE_D5, 500}, {NOTE_D5, 500}, {NOTE_E5, 375}, {NOTE_B4, 125}, {NOTE_G4, 500}, {NOTE_E4, 375}, {NOTE_B4, 125}, {NOTE_G4, 1000}, // Segundo compás
            {-1, 0} 
        } 
    },
    // Harry Potter
    { "Melodia B", 
        {
            {NOTE_E5, 300}, {NOTE_G5, 300}, {NOTE_FS5, 300}, {NOTE_E5, 300}, {NOTE_B5, 300}, {NOTE_A5, 300}, {NOTE_FS5, 300}, {NOTE_D5, 300}, {NOTE_B5, 300}, // Primer compás
            {NOTE_A5, 300}, {NOTE_FS5, 300}, {NOTE_E5, 300}, {NOTE_G5, 300}, {NOTE_FS5, 300}, {NOTE_D5, 300}, {NOTE_A5, 300}, {NOTE_FS5, 300}, {NOTE_E5, 600}, // Segundo compás
            {-1, 0} 
        } 
    },
    // Indiana Jones
    { "Melodia C", 
        {
            {NOTE_E4, 300}, {NOTE_F4, 300}, {NOTE_G4, 600}, {NOTE_C4, 300}, {NOTE_E4, 300}, {NOTE_F4, 300}, {NOTE_D4, 300}, {NOTE_E4, 600}, // Primer compás
            {NOTE_E4, 300}, {NOTE_F4, 300}, {NOTE_G4, 600}, {NOTE_C4, 300}, {NOTE_E4, 300}, {NOTE_F4, 300}, {NOTE_D4, 300}, {NOTE_E4, 600}, // Segundo compás
            {-1, 0} 
        } 
    },
    // Piratas del Caribe
    { "Melodia D", 
        {
            {NOTE_E4, 300}, {NOTE_G4, 300}, {NOTE_A4, 300}, {NOTE_B4, 300}, {NOTE_C5, 300}, {NOTE_D5, 300}, {NOTE_E5, 300}, {NOTE_G5, 600}, // Primer compás
            {NOTE_E5, 300}, {NOTE_D5, 300}, {NOTE_C5, 300}, {NOTE_B4, 300}, {NOTE_A4, 300}, {NOTE_G4, 300}, {NOTE_E4, 300}, {NOTE_D4, 600}, // Segundo compás
            {NOTE_E4, 300}, {NOTE_G4, 300}, {NOTE_A4, 300}, {NOTE_B4, 300}, {NOTE_C5, 300}, {NOTE_D5, 300}, {NOTE_E5, 300}, {NOTE_G5, 600}, // Tercer compás
            {-1, 0} 
        } 
    }
};

void setup() {
    Serial.begin(115200);
    Serial1.begin(115200);
    setupPins();
    setupLCD();
}

void setupPins() {
    pinMode(pinA, INPUT);
    pinMode(pinB, INPUT);
    pinMode(pinSw, INPUT_PULLUP);
    pinMode(pinZ, OUTPUT);
}

void setupLCD() {
    lcd.begin(16, 2);
    lcd.setRGB(200, 200, 200);
    lcd.print("Creador de");
    lcd.setCursor(0, 2);
    lcd.print("melodias");
    delay(2000);
    lcd.clear();
    lcd.print("Introduce 10");
    lcd.setCursor(0, 2);
    lcd.print("notas");
    delay(2000);
    lcd.clear();
    lcd.print("Nota: DO");
}

void handleEncoder() {
    static int pinALastState = digitalRead(pinA);
    int pinAState = digitalRead(pinA);

    if (pinAState != pinALastState && pinAState == HIGH) {
        if (digitalRead(pinB) == LOW) {
            noteSelection = (noteSelection + 1) % 8;
        } else {
            noteSelection = (noteSelection - 1 + 8) % 8;
        }
        lcd.setCursor(6, 0);
        lcd.print("    ");
        lcd.setCursor(6, 0);
        lcd.print(noteNames[noteSelection]);
    }
    pinALastState = pinAState;
}

void handleSwitchPress() {
    bool switchPressed = (digitalRead(pinSw) == LOW);

    if (switchPressed && (millis() - lastSwitchPressTime) > debounceTime) {
        switchPressCount++;
        lastSwitchPressTime = millis();
        delay(100);
    }

    if (!switchPressed && (millis() - lastSwitchPressTime) > debounceTime) {
        if (switchPressCount == 1) {
            addNote();
        } else if (switchPressCount == 2) {
            saveMelody();
        } else if (switchPressCount == 3) {
            deleteLastNote();
        } else if (switchPressCount == 4) {
            deleteAllNotes();
        }
        switchPressCount = 0;
    }
}

void addNote() {
    melodies[currentMelodyIndex].notes[currentNoteIndex] = { noteFrequencies[noteSelection], 250 };
    currentNoteIndex++;
    lcd.setCursor(0, 1);
    lcd.print("Notas: ");
    lcd.print(currentNoteIndex);
    lcd.print("  ");
}

void saveMelody() {
    melodies[currentMelodyIndex].noteCount = currentNoteIndex;
    melodyCount++;
    snprintf(melodies[currentMelodyIndex].name, MELODY_NAME_LEN, "melodia%d", melodyCount);
    lcd.clear();
    lcd.print("Melodia guardada");

    // definimos la variable melodyName para guardar el nombre de la melodía creada
    const char* melodyName = melodies[currentMelodyIndex].name;
    
    delay(2000);
    lcd.clear();
    lcd.print("Crear otra?");
    lcd.setCursor(0, 1);
    lcd.print("[Si] No");
    confirmSave = true;
    confirmSaveLoop();

    sendMelodyToESP32(melodyName);
    
}

void confirmSaveLoop() {
    static int pinALastState = digitalRead(pinA);
    int pinAState;

    while (true) {
        pinAState = digitalRead(pinA);
        if (pinAState != pinALastState && pinAState == HIGH) {
            if (digitalRead(pinB) == LOW) {
                confirmSave = !confirmSave;
            } else {
                confirmSave = !confirmSave;
            }
            lcd.setCursor(0, 1);
            lcd.print("        ");
            lcd.setCursor(0, 1);
            lcd.print(confirmSave ? "[Si] No" : " Si [No]");
        }
        pinALastState = pinAState;

        if (digitalRead(pinSw) == LOW) {
            delay(200);
            if (confirmSave) {
                currentNoteIndex = 0;
                currentMelodyIndex = melodyCount;
                lcd.clear();
                lcd.print("Nota: DO");
            } else {
                lcd.clear();
                lcd.print("Total melodias:");
                lcd.setCursor(0, 1);
                lcd.print(melodyCount);
                while (true){}; //mantener el mensaje
            }
            break;
        }
    }
}

void deleteLastNote() {
    if (currentNoteIndex > 0) {
        currentNoteIndex--;
        lcd.setCursor(0, 1);
        lcd.print("Notas: ");
        lcd.print(currentNoteIndex);
        lcd.print("  ");
    }
}

void deleteAllNotes() {
    currentNoteIndex = 0;
    lcd.setCursor(0, 1);
    lcd.print("Notas: ");
    lcd.print(currentNoteIndex);
    lcd.print("  ");
}

void playMelody(int frequency, int duration) {
    if (frequency == 0) {
        noTone(pinZ);
    } else {
        tone(pinZ, frequency, duration);
    }
    delay(duration);
}

void playMelodiesFromESP32(String melodyName) {

    for (int i = 0; i < 4; i++) {
        if (String(predefinedMelodies[i].name) == melodyName) {
            for (int j = 0; j < 50 && predefinedMelodies[i].notes[j].frequency != -1; j++) {
                playMelody(predefinedMelodies[i].notes[j].frequency, predefinedMelodies[i].notes[j].duration);
            }
            return; 
        }
    }

    for (int i = 0; i < (melodyCount); i++) {
        if (String(melodies[i].name) == melodyName) {
            for (int j = 0; j < melodies[i].noteCount; j++) {
                playMelody(melodies[i].notes[j].frequency, melodies[i].notes[j].duration);
            }
            return; 
        }
    }

    Serial.println("Error: Melodía no encontrada");
}

void sendMelodyToESP32(const char* melodyName) {
    Serial1.print("M:");
    Serial1.println(melodyName);
    // comprobar que se está enviando la melodía correctamente
    Serial.print("Sending melody: ");
    Serial.println(melodyName);
    delay(100);
}

void loop() {
    handleEncoder();
    handleSwitchPress();

    if (Serial1.available() > 0) {
        String message = Serial1.readStringUntil('\n');
        if (message.startsWith("M:")) {
            String melodyName = message.substring(2);
            melodyName.trim();  // quitar espacios o newlines
            playMelodiesFromESP32(melodyName);
        }
    }
}