@echo off

set MKSPIFFS=%LOCALAPPDATA%\Arduino15\packages\esp32\tools\mkspiffs\0.2.3\mkspiffs.exe
set ESPTOOL=%LOCALAPPDATA%\Arduino15\packages\esp32\tools\esptool_py\4.5.1\esptool.exe
set PARTITION_FILE=%LOCALAPPDATA%\Arduino15\packages\esp32\hardware\esp32\2.0.16\tools\partitions\default.csv

set FS_DATADIR=%~dp0data
set FS_IMAGE=%~dp0spiffs.bin
set FS_BLOCKSIZE=4096
set FS_PAGESIZE=256

set ESP32_PORT=COM3
set ESP32_BAUDS=921600

if not exist "%MKSPIFFS%" (
    echo "ERROR: Cannot find %MKSPIFFS%"
    goto FINISH
)

if not exist "%ESPTOOL%" (
    echo "ERROR: Cannot find %ESPTOOL%"
    goto FINISH
)

if not exist "%PARTITION_FILE%" (
    echo "ERROR: Cannot find %PARTITION_FILE%"
    goto FINISH
)

if not exist "%FS_DATADIR%" (
    echo "ERROR: Cannot find %FS_DATADIR%"
    goto FINISH
)

for /f "tokens=4 delims=," %%x in ('findstr "^spiffs" "%PARTITION_FILE%"') do (
    set FS_ADDR=%%x
)
if "%FS_ADDR%"=="" (
    echo "ERROR: Cannot find SPIFFS partition address in %PARTITION_FILE%"
    goto FINISH
)

for /f "tokens=5 delims=," %%x in ('findstr "^spiffs" "%PARTITION_FILE%"') do (
    set FS_SIZE=%%x
)
if "%FS_SIZE%"=="" (
    echo "ERROR: Cannot find SPIFFS partition size in %PARTITION_FILE%"
    goto FINISH
)

echo - Creating %FS_IMAGE% from %FS_DATADIR% folder...
"%MKSPIFFS%" -c %FS_DATADIR% -b %FS_BLOCKSIZE% -p %FS_PAGESIZE% -s %FS_SIZE% "%FS_IMAGE%"

echo - Deploying %FS_IMAGE%...
"%ESPTOOL%" --chip esp32 -p %ESP32_PORT% -b %ESP32_BAUDS% write_flash -z %FS_ADDR% "%FS_IMAGE%"

:FINISH
pause